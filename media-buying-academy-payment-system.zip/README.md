# Media Buying Academy — Proper Paystack Payment System

## What this does

- Keeps the Paystack SECRET key on the backend.
- Initializes card payments on the backend.
- Stores an order before payment starts.
- Verifies card payments server-side.
- Uses Paystack `charge.success` webhooks as the authoritative successful-payment signal.
- Checks the exact expected amount: ₦35,000 = 3,500,000 kobo.
- Uses HMAC SHA-512 to validate Paystack webhook signatures.
- Uses a real Paystack Dedicated Virtual Account for transfer payments.
- Does not trust the "I have paid" button as proof of payment.
- Makes the thank-you page query the backend before showing "Payment confirmed."

Paystack recommends server-side initialization and verification, checking both `data.status` and `data.amount`, and using webhooks rather than relying only on browser callbacks. citeturn0search9turn0search8

Dedicated Virtual Accounts are only available to eligible/registered businesses that have completed Paystack's go-live process. citeturn1search2

## 1. Install

```bash
npm install
```

## 2. Create `.env`

Copy `.env.example` to `.env` and fill in:

- `PAYSTACK_SECRET_KEY`
- `MONGODB_URI`
- `PUBLIC_URL`

NEVER put `PAYSTACK_SECRET_KEY` inside checkout.html or any frontend JavaScript.

## 3. Run locally

```bash
npm start
```

Then open:

```text
http://localhost:3000/checkout.html?name=Jane%20Doe&email=jane@example.com&phone=08012345678
```

## 4. Paystack webhook

In your Paystack dashboard, set your webhook URL to:

```text
https://YOUR-BACKEND-DOMAIN.com/api/paystack/webhook
```

Your backend must be publicly reachable over HTTPS for Paystack to call it.

The webhook code validates the `x-paystack-signature` HMAC SHA-512 signature before processing the event.

## 5. Important: transfer payments

The transfer panel now creates a real Paystack Dedicated Virtual Account instead of inventing an account number in JavaScript.

Your Paystack account must be eligible for Dedicated Virtual Accounts. Paystack says DVA availability is tied to registered businesses that have completed the go-live process. citeturn1search2turn1search1

When the customer transfers ₦35,000, Paystack sends a `charge.success` webhook for the DVA payment. The backend then marks the matching order as paid only when the event is successful and the amount is exactly ₦35,000. citeturn1search2turn0search4

## 6. Production deployment

This backend needs:

- Node.js 18+
- MongoDB Atlas or another persistent MongoDB service
- A public HTTPS URL
- Environment variables configured on the hosting provider

Do not use a frontend-only host for this backend unless it supports the required server-side API routes and environment variables.

## 7. Before going live

Test with Paystack test keys first.

Then switch to live keys only after:

1. Card payment is successfully initialized.
2. Webhook reaches `/api/paystack/webhook`.
3. Webhook signature is accepted.
4. The exact ₦35,000 amount is checked.
5. The order becomes `paid`.
6. The thank-you page only says "Payment confirmed" after the backend says `paid`.
7. Transfer/DVA creation works on the live Paystack account.

## 8. Next step: access delivery

The current thank-you page verifies payment but does not yet deliver the academy login/course access.

Once payment is verified, you can safely trigger your actual fulfillment logic from the backend. Keep that fulfillment idempotent so the same transaction cannot create duplicate access.
