require("dotenv").config();

const express = require("express");
const crypto = require("crypto");
const mongoose = require("mongoose");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

const PAYSTACK_SECRET_KEY = process.env.PAYSTACK_SECRET_KEY;
const PUBLIC_URL = process.env.PUBLIC_URL || `http://localhost:${PORT}`;
const AMOUNT_KOBO = 35000 * 100;

if (!PAYSTACK_SECRET_KEY) {
  console.warn("WARNING: PAYSTACK_SECRET_KEY is not set.");
}

/* ---------------- Database ---------------- */
const orderSchema = new mongoose.Schema(
  {
    name: String,
    email: { type: String, required: true, lowercase: true, index: true },
    phone: String,

    amount: { type: Number, required: true },
    currency: { type: String, default: "NGN" },

    reference: { type: String, unique: true, sparse: true, index: true },
    paystackTransactionId: String,

    status: {
      type: String,
      enum: ["pending", "paid", "failed"],
      default: "pending",
      index: true
    },

    paymentMethod: {
      type: String,
      enum: ["card", "transfer"],
      required: true
    },

    customerCode: String,
    virtualAccount: {
      bankName: String,
      accountName: String,
      accountNumber: String,
      providerSlug: String
    },

    paidAt: Date,
    webhookEvent: String
  },
  { timestamps: true }
);

const Order = mongoose.model("Order", orderSchema);

/* ---------------- Paystack helper ---------------- */
async function paystack(pathname, options = {}) {
  if (!PAYSTACK_SECRET_KEY) {
    throw new Error("PAYSTACK_SECRET_KEY is not configured.");
  }

  const response = await fetch("https://api.paystack.co" + pathname, {
    ...options,
    headers: {
      Authorization: `Bearer ${PAYSTACK_SECRET_KEY}`,
      "Content-Type": "application/json",
      ...(options.headers || {})
    }
  });

  const data = await response.json();

  if (!response.ok || !data.status) {
    throw new Error(data.message || "Paystack request failed.");
  }

  return data;
}

/* ---------------- Webhook ----------------
   IMPORTANT: raw body MUST be available so HMAC SHA512 can be checked. */
app.post(
  "/api/paystack/webhook",
  express.raw({ type: "application/json" }),
  async (req, res) => {
    try {
      const signature = req.headers["x-paystack-signature"];
      const expected = crypto
        .createHmac("sha512", PAYSTACK_SECRET_KEY)
        .update(req.body)
        .digest("hex");

      if (!signature || !crypto.timingSafeEqual(
        Buffer.from(signature),
        Buffer.from(expected)
      )) {
        return res.status(401).send("Invalid signature");
      }

      const event = JSON.parse(req.body.toString("utf8"));

      // Acknowledge quickly. Paystack retries webhook events if it doesn't get 200.
      res.sendStatus(200);

      if (event.event !== "charge.success") return;

      const data = event.data || {};
      const amount = Number(data.amount);
      const status = data.status;

      // Never grant access unless the successful event has the exact expected amount.
      if (status !== "success" || amount !== AMOUNT_KOBO) return;

      const reference = data.reference;

      const order = await Order.findOne({
        $or: [
          { reference },
          { "virtualAccount.accountNumber": data.authorization?.receiver_bank_account_number }
        ]
      });

      if (!order) {
        console.warn("No matching order for webhook:", reference);
        return;
      }

      // Idempotent fulfillment: once paid, don't fulfill again.
      if (order.status === "paid") return;

      order.status = "paid";
      order.paidAt = new Date();
      order.paystackTransactionId = String(data.id || "");
      order.reference = reference || order.reference;
      order.webhookEvent = event.event;
      await order.save();

      console.log("PAYMENT VERIFIED:", order._id.toString());
    } catch (error) {
      console.error("Webhook error:", error);
      // The event may be retried if processing fails before a 200.
      if (!res.headersSent) res.status(500).send("Webhook error");
    }
  }
);

/* All normal JSON routes come AFTER webhook. */
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

/* ---------------- Initialize card payment ---------------- */
app.post("/api/initialize-payment", async (req, res) => {
  try {
    const { name, email, phone } = req.body;

    if (!email) {
      return res.status(400).json({ success: false, message: "Email is required." });
    }

    const reference = `MBA-${Date.now()}-${crypto.randomBytes(4).toString("hex")}`;

    const order = await Order.create({
      name: name || "Customer",
      email,
      phone: phone || "",
      amount: AMOUNT_KOBO,
      paymentMethod: "card",
      reference,
      status: "pending"
    });

    const result = await paystack("/transaction/initialize", {
      method: "POST",
      body: JSON.stringify({
        email,
        amount: AMOUNT_KOBO,
        currency: "NGN",
        reference,
        callback_url: `${PUBLIC_URL}/thankyou.html`,
        metadata: {
          order_id: order._id.toString(),
          full_name: name || "Customer",
          phone: phone || ""
        }
      })
    });

    res.json({
      success: true,
      orderId: order._id,
      reference: result.data.reference,
      accessCode: result.data.access_code,
      authorizationUrl: result.data.authorization_url
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: error.message });
  }
});

/* ---------------- Create real Paystack transfer account ---------------- */
app.post("/api/create-transfer-account", async (req, res) => {
  try {
    const { name, email, phone } = req.body;

    if (!email) {
      return res.status(400).json({ success: false, message: "Email is required." });
    }

    const parts = String(name || "Customer").trim().split(/\s+/);
    const firstName = parts.shift() || "Customer";
    const lastName = parts.join(" ") || "Customer";

    // Create the Paystack customer.
    const customerResult = await paystack("/customer", {
      method: "POST",
      body: JSON.stringify({
        email,
        first_name: firstName,
        last_name: lastName,
        phone: phone || undefined
      })
    });

    const customer = customerResult.data;

    // Create a real Dedicated Virtual Account.
    // DVA availability depends on Paystack account eligibility/go-live.
    const dvaResult = await paystack("/dedicated_account", {
      method: "POST",
      body: JSON.stringify({
        customer: customer.customer_code,
        preferred_bank: process.env.PAYSTACK_DVA_BANK || "titan-paystack"
      })
    });

    const dva = dvaResult.data;

    const order = await Order.create({
      name: name || "Customer",
      email,
      phone: phone || "",
      amount: AMOUNT_KOBO,
      paymentMethod: "transfer",
      customerCode: customer.customer_code,
      virtualAccount: {
        bankName: dva.bank?.name,
        accountName: dva.account_name,
        accountNumber: dva.account_number,
        providerSlug: dva.bank?.slug
      },
      status: "pending"
    });

    res.json({
      success: true,
      orderId: order._id,
      bankName: dva.bank?.name,
      accountName: dva.account_name,
      accountNumber: dva.account_number
    });
  } catch (error) {
    console.error("DVA error:", error);
    res.status(500).json({
      success: false,
      message:
        error.message ||
        "Unable to create a Paystack transfer account. Confirm that Dedicated Virtual Accounts are enabled for your Paystack business."
    });
  }
});

/* ---------------- Verify a card reference from SERVER ---------------- */
app.get("/api/verify/:reference", async (req, res) => {
  try {
    const result = await paystack(`/transaction/verify/${encodeURIComponent(req.params.reference)}`);
    const data = result.data;

    const order = await Order.findOne({ reference: data.reference });

    if (!order) {
      return res.status(404).json({ success: false, message: "Order not found." });
    }

    const paid = data.status === "success" && Number(data.amount) === AMOUNT_KOBO;

    if (paid && order.status !== "paid") {
      order.status = "paid";
      order.paidAt = new Date();
      order.paystackTransactionId = String(data.id || "");
      await order.save();
    }

    res.json({
      success: true,
      paid,
      status: data.status,
      amount: Number(data.amount),
      reference: data.reference
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: error.message });
  }
});

/* ---------------- Order status ---------------- */
app.get("/api/orders/:id", async (req, res) => {
  try {
    const order = await Order.findById(req.params.id).lean();

    if (!order) {
      return res.status(404).json({ success: false, message: "Order not found." });
    }

    res.json({
      success: true,
      paid: order.status === "paid",
      status: order.status,
      paymentMethod: order.paymentMethod,
      reference: order.reference || null,
      amount: order.amount,
      currency: order.currency,
      virtualAccount:
        order.status === "paid"
          ? null
          : order.virtualAccount || null
    });
  } catch (error) {
    res.status(400).json({ success: false, message: "Invalid order ID." });
  }
});

app.get("/health", (req, res) => {
  res.json({ ok: true });
});

async function start() {
  await mongoose.connect(process.env.MONGODB_URI);
  console.log("MongoDB connected");
  app.listen(PORT, () => console.log(`Server running on ${PUBLIC_URL}`));
}

start().catch((error) => {
  console.error("Server failed to start:", error);
  process.exit(1);
});
